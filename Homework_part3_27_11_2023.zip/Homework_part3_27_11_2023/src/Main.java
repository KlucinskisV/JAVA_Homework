import java.time.DayOfWeek;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

//Используйте foreach.
//Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
// Программа должна вывести все дни недели, кроме данного.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(Arrays.toString(DayOfWeek.values()));
        System.out.println("Whrite please Day , which you dont't want to see : ");
        String userDay = scanner.nextLine();
        DayOfWeek userChoceDay = DayOfWeek.valueOf(userDay.toUpperCase(Locale.ROOT));
        for (DayOfWeek day:DayOfWeek.values()) {
            if (day != userChoceDay) System.out.print(day+ " ");

        }
        System.out.println("Thanks for your Choice!");
    }
}