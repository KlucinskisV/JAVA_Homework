public class Main {
    public static void main(String[] args) {
        //Создайте строку через new - I study Basic Java!
        //Напишите метод, который принимает в качестве параметра строку,
        // передайте в этот метод созданную строку
        //Распечатать последний символ строки. Используем метод String.charAt().
        //Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
        //Заменить все символы “а” на “о”.
        //Преобразуйте строку к верхнему регистру.
        //Преобразуйте строку к нижнему регистру.
        //Вырезать строку Java c помощью метода String.substring().

        String string = "I study Basic Java!";
        System.out.println(string);
        System.out.println(string.charAt(string.length()-1));
        System.out.println(string.contains("Java"));
        System.out.println(string.replace("a","o"));
        System.out.println(string.toUpperCase());
        System.out.println(string.toLowerCase());
        System.out.println(string.substring(0,string.indexOf("Java")));
    }
}