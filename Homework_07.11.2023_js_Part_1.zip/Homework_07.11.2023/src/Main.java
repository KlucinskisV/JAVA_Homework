public class Main {
    public static void main(String[] args) {
        char g='G';
        System.out.println(g);
        int b= 89;
        System.out.println(b);
        byte c=4;
        System.out.println(c);
        short d=56;
        System.out.println(d);
        float f=47333436;
        System.out.println(f);
        double a=4.355453532;
        System.out.println(a);
        long l=12121;
        System.out.println(l);

    }

}