import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //  1 уровень сложности: 1 Дана длина в метрах. Напишите программу,
        //  которая переводит указанное значение в км, мили, футы и аршины.
        //  Выведите начальное и конвертированные значения на экран.
        Scanner scr = new Scanner(System.in);
        System.out.println("Input metrs :" );
        int metr = scr.nextInt();
        int km = metr / 1000;
        double mil = metr * 0.00062137;
        double ft = metr * 3.2808;
        double Arg =  metr * 0.00000000001;
        System.out.println("Your written meaning : "+metr + " metrs");
        System.out.println("In Kilometers  is : " + km + " KM");
        System.out.println("In Miles is : " + mil + " Mils");
        System.out.println("In Fiets is  : " + ft + " Ft");
        System.out.println("In Angstrom  is : " + Arg + " Angstrom");

    }
}