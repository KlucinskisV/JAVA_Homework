import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Создайте массив из 8 случайных целых чисел из интервала [1;50]
        //Выведите массив в консоль в строку.
        //Замените каждый элемент с нечетным индексом на ноль.
        //Снова выведете массив в консоль в отдельной строке.
        //Отсортируйте массив по возрастанию.
        //Снова выведете массив в консоль в отдельной строке.

        int[] massiv = new int[8];
        Random random = new Random();
                for (int i = 0; i < massiv.length; i++) {
            massiv[i] = random.nextInt(1,50);
            System.out.println(Arrays.toString(massiv));

                }

        for (int i = 0; i < massiv.length; i++) {
            if (massiv[i] % 2 == 1 ){
                massiv[i]=0;
            }

        }
        System.out.println(Arrays.toString(massiv));
        Arrays.sort(massiv);
        for (int sortmasiv : massiv) {
            System.out.print(sortmasiv+" ");


        }

    }
}