import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        //Задание из собеседования Яндекс:
        //дана строка вида AAAABBBCCCDDEG…,
        // состоящая только из заглавных символов латинского алфавита.
        // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG,
        // т.е. количество букв записывается цифрой.
        // Если буква одна, то цифра не ставится.

        String string = "AAAABBBCCCDDEG";
        System.out.println(" дана строка вида AAAABBBCCCDDEG \nНапишите метод, который «свернёт» строку к виду A4B3C3D2EG ");
        int a = string.split("A", -1).length - 1;
        int b = string.split("B", -1).length - 1;
        int c = string.split("C", -1).length - 1;
        int d = string.split("D", -1).length - 1;
        System.out.println("Answer : \n" + "A" + a + "B" + b + "C" + c + "D" + d + "EG");

        System.out.println("--------------------------------------------------\nSecond value");
        int count = 0;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        for (int i = 0; i <= string.length() - 1; i++) {
            if (string.charAt(i) == 'A') {
                count++;
            }
            if (string.charAt(i) == 'B') {
                count1++;
            }
            if (string.charAt(i) == 'C') {
                count2++;
            }
            if (string.charAt(i) == 'D') {
                count3++;
            }


        }
        System.out.println("A" + count + "B" + count1 + "C" + count2 + "D" + count3+"EG");

    }
}