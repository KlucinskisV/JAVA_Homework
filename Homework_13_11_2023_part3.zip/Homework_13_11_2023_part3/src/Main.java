import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //№3 Напишите программу, которая получает от пользователя два целых числа
        // и затем вычисляет сумму (сложение), разницу (вычитание),
        // произведение (умножение) и частное (деление) введённых чисел.
        // Результат вычисления выведите в консоль.
        System.out.println("Input First Number in consol : ");
        Scanner scr = new Scanner(System.in);
        int num1 = scr.nextInt();
        System.out.println("Input Second Number in consol : ");
        Scanner scr1 = new Scanner(System.in);
        int num2 = scr1.nextInt();
        int sum = num1+num2;
        int sum2 = num1-num2;
        int sum3 = num1*num2;
        int sum4 = num1/num2;

        System.out.println("Cуммa сложение :"+sum+" Pазницу вычитание :"+sum2);
        System.out.println("произведение умножение :"+sum3+" частное деление :"+sum4);


    }
}