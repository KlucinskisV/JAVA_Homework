import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insert factorial number from 1 to 20 :");
        int userInsert = scanner.nextInt();
        int numfact = factoryCalcul(userInsert);

        System.out.println("Factorial Number :" + numfact);
    }
    private static int factoryCalcul(int n){
      if (n==0) {
          return 1 ;
      }else return n * factoryCalcul(n-1);
    }
}