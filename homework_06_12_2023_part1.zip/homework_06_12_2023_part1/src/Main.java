import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        //1 Создайте массив из 8 элементов. В массиве должны храниться даты
        // (класс LocalDate). Чтобы создать элемент LocalDate используйте
        // метод LocalDate.of(год, месяц, день), где год, месяц и день – целые числа.
        //Выведите массив в консоль.
        //2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
        //3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.
        //Сортировку можно выполнить по любому из изученных алгоритмов.
        //Пример создания массива с датами:
        LocalDate[] loclDate = new LocalDate[]{
                LocalDate.of(1960, 6, 12),
                LocalDate.of(1977, 8, 19),
                LocalDate.of(1990, 9, 29),
                LocalDate.of(2000, 4, 19),
                LocalDate.of(2010, 8, 20),
                LocalDate.of(2020, 10, 6),
                LocalDate.of(1998, 4, 22),
                LocalDate.of(2010, 7, 14),
        };

        System.out.print(Arrays.toString(loclDate));

        Arrays.sort(loclDate);
        for (LocalDate sortlocalDate:loclDate){
            System.out.println(sortlocalDate.toString()+" Complet sorting");

        }
        Arrays.sort(loclDate, Comparator.comparing(LocalDate::getMonth));
        for (LocalDate sortDays:loclDate) {
            System.out.println(sortDays + "\n Month Sorting");

        }
        Arrays.sort(loclDate, Comparator.comparing(LocalDate::getYear));
        for (LocalDate sortYears : loclDate) {
            System.out.println(sortYears + "\n Years Sorting");


        }




    }

}