import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Задание 1. Введите 2 слова, воспользуйтесь сканером,
        // состоящие из четного количества букв (проверьте количество букв в слове).
        //Нужно получить слово, состоящее из первой половины первого слова
        // и второй половины второго слова. распечатать на консоль.
        //Например: ввод - mama, papa. Вывод – mapa


        System.out.println("Cостоящие из четного количества букв\nВведите 1 слова :");
        Scanner scanner = new Scanner(System.in);
        String userInput1 =scanner.nextLine();
        System.out.println("Введите 2 слова :");
        String userInput2 = scanner.nextLine();
        String  userAnswer = (userInput1.substring(0,userInput1.length()/2))+(userInput2.substring(userInput2.length()/2));
        System.out.println(userAnswer);
        String userAnswer3 = "";
        int userAnswer1 = userInput1.length()%2;
        int userAnswer2 = userInput2.length()%2;
        userAnswer3 = userAnswer1 <userAnswer2  || userAnswer1 >userAnswer2 ? " нeчетного количества букв net":"нeчетного количества букв нe moгу распечатать";
        System.out.println(userAnswer3);




    }
}