import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Напиши программу, которая моделирует ситуацию.
        //Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
        // Каждый друг случайным образом может подарить тебе одну купюру номиналом
        // 50, 100, 200 или 500 долларов.
        // Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
        //Как только друзья подарят тебе нужную сумму (или даже чуть больше),
        // останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
        int value = 0;
        int value1 = 50;
        int value2 = 11000;


        System.out.println("попросил(а) друзей скинуться на подарок на твой День Рождения");

        for (int i = 0; i < value1; i++) {


            Random random = new Random();

            int frend1 = 50;
            int frend2 = 100;
            int frend3 = 200;
            int frend4 = 500;

            int rndfrend = random.nextInt(4);
            int  num = switch (rndfrend) {
                case 1 -> frend1;
                case 2 -> frend2;
                case 3 -> frend3;
                default -> frend4;
            }; value = value +num;

            System.out.println("друзья скидывa"+num);
            System.out.println( "Summma vsex"+value);
        }
            do {
                value = value + 1000;




            }while (value == value2);
        System.out.println("BRAVO !!!! останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города! " + value);
        }

    }