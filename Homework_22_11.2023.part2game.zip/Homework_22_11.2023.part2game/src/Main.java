import gameVariars.GameVariars;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import java.util.Locale;
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
                System.out.println("Input Please Your Chice : ");
        System.out.println(Arrays.toString(GameVariars.values()));
                String userchiose = scanner.nextLine();
                GameVariars userChiose = GameVariars.valueOf(userchiose.toUpperCase(Locale.ROOT));
        System.out.println("User chioce is : "+ userchiose+"!!!");

        Random random = new Random();
        int comprandom = random.nextInt(3);
        GameVariars computerChioce = switch (comprandom){
            case 0 -> GameVariars.ROCK;
            case 1 -> GameVariars.PAPER;
            default -> GameVariars.SCISERS;
        };
        System.out.println("Computer did his chiose too : " + computerChioce + "!!!");
        if (computerChioce == userChiose)
            System.out.println("OOOOO NOOOooo we have a DRAW ! TRY AGAN =) ");
        else if (userChiose == GameVariars.PAPER && computerChioce == GameVariars.ROCK ||
                userChiose == GameVariars.ROCK && computerChioce == GameVariars.SCISERS) {
            System.out.println("You WIN!!!! NICE JoB !!!");


        }else System.out.println("Computer Win =P !?!?!?");

    }
}