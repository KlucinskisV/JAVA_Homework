package gameVariars;

public enum GameVariars {
    ROCK,
    PAPER,
    SCISERS,
}
