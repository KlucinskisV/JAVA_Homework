import java.util.Arrays;
import java.util.Scanner;
import Marriage_pack.marriage;


public class Main {
    public static void main(String[] args) {
        // Пользователь вводит, сколько лет он состоит в браке.
        // Программа должна вывести, какая годовщина свадьбы будет у
        // пользователя следующей (бумажная, ситцевая, чугунная, серебряная и.д.).
        // Не обязательно указывать все годовщины, достаточно 10-15.
        // Узнать про годовщины можно, например, здесь
        // https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
        Scanner scr = new Scanner(System.in);
        System.out.println("Пользователь введите, сколько лет вы состоит в браке : ");
        int mar = scr.nextInt();
        int mar2 = mar + 1;
        marriage userMarstat = switch (mar){
            case 1 -> marriage.GAUZE_WEDDING;
            case 2 -> marriage.PAPER_WEDDING;
            case 3 -> marriage.LEATHER_WEDDING;
            case 4 -> marriage.LINEN_WEDDING;
            case 5 -> marriage.WOODEN_WEDDING;
            case 6 -> marriage.CAST_IRON_WEDDING;
            case 7 -> marriage.COPPER_WEDDING;
            case 8 -> marriage.TINPLATE_WEDDING;
            case 9 -> marriage.FAIENCE_WEDDING;
            case 10 ->marriage.TIN_WEDDING;
            case 11->marriage.STEEL_WEDDING;
            case 12 ->marriage.NICKEL_WEDDING;
            case 13 ->marriage.LACE_WEDDING;
            case 14 ->marriage.AGATE_WEDDING;
            case 15 ->marriage.CRYSTAL_WEDDING;
            case 16 ->marriage.TOPAZOV_WEDDING;
            case 17 ->marriage.PINK_WEDDING;
            case 18 ->marriage.TURQUOISE_WEDDING;
            case 19 ->marriage.POMEGRANATE_WEDDING;
            default -> marriage.UNKNOWN_VALUE;
        };
        marriage userMarstat2 = switch (mar2){
            case 1 -> marriage.GAUZE_WEDDING;
            case 2 -> marriage.PAPER_WEDDING;
            case 3 -> marriage.LEATHER_WEDDING;
            case 4 -> marriage.LINEN_WEDDING;
            case 5 -> marriage.WOODEN_WEDDING;
            case 6 -> marriage.CAST_IRON_WEDDING;
            case 7 -> marriage.COPPER_WEDDING;
            case 8 -> marriage.TINPLATE_WEDDING;
            case 9 -> marriage.FAIENCE_WEDDING;
            case 10 ->marriage.TIN_WEDDING;
            case 11->marriage.STEEL_WEDDING;
            case 12 ->marriage.NICKEL_WEDDING;
            case 13 ->marriage.LACE_WEDDING;
            case 14 ->marriage.AGATE_WEDDING;
            case 15 ->marriage.CRYSTAL_WEDDING;
            case 16 ->marriage.TOPAZOV_WEDDING;
            case 17 ->marriage.PINK_WEDDING;
            case 18 ->marriage.TURQUOISE_WEDDING;
            case 19 ->marriage.POMEGRANATE_WEDDING;
            default -> marriage.UNKNOWN_VALUE;
        };
        System.out.println("You have Now "+ userMarstat+ " . Congratulation!!!");
        System.out.println("Next Year You have "+ userMarstat2 + " Dont for got buy flowers !!! ");


        }







    }