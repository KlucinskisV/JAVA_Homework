import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Необходимо написать программу,
        // которая проверяет пользователя на знание таблицы умножения.
        // Программа генерирует два целых однозначных числа.
        // Программа задаёт вопрос: результат умножения первого числа на второе?
        // Пользователь должен ввести ответ и увидеть на экране правильно
        // он ответил или нет.
        // Если пользователь ответил неправильно,
        // то программа должна показать правильный ответ.

        Random random = new Random();
        int num1 = random.nextInt(0,10);
        int num2 = random.nextInt(0,10);
        System.out.println("Fist Number : "+num1+" Second Number : "+num2);
        System.out.println("How much will be multiplied "+num1+" And "+ num2);
        int num_munlti = num1 * num2;
        Scanner scr = new Scanner(System.in);
        System.out.println("Write your answer :");
        int userNum = scr.nextInt();
        if (userNum == num_munlti)
        System.out.println("Правильно пользователь ответил !!! It is true : "+num_munlti);
        else System.out.println("Пользователь ответил неправильно !?!  " +userNum+ "Правильный ответ : "+num_munlti);

    }
}