import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
// Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
// которую дал покупатель.
// Выведите сумму сдачи в виде “X рублей и Y копеек”.
        Scanner scr = new Scanner(System.in);
        System.out.println("Input Product price :");
        float prod = scr.nextFloat();
        System.out.println("Input next price :");
        float prod2 = scr.nextFloat();
        float sum1 =prod + prod2;
        Scanner scr2 = new Scanner(System.in);
        System.out.println("Client Summ :");
        float client_sum = scr2.nextFloat();
        int total = (int) (client_sum - sum1);
        float total2 =client_sum - sum1; total2 = total2 - total;
        System.out.println("You Give Back : "+total+" рублей " +total2%2+" копеек");
        System.out.println("Have nice Day !");


    }
}