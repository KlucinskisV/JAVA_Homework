import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Создать программу, выводящую на экран ближайшее к 10 из двух чисел,
        // записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
        //Например :
        //ввод : m=7, n=11
        //вывод: Число 11 ближе к 10.
int num_m = 7;
int num_n = 11;
int num_d  = 10;
int more = num_d -num_m;
int more2 = num_d - num_n;
if (more < more2)
    System.out.println("Number M came later");
    else {
    System.out.println("Number N it's closer");
}

    }


}