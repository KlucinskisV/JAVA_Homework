import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.
        //
        //
        //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем. Программу повторять, пока пользователь не введёт «quit».
        String user = "";
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input first number: ");
        int usernumber1 = scanner.nextInt();
        System.out.println("Input second number: ");
        int usernumber2 = scanner.nextInt();
        int summatotal =0;
        int summamin = 0;
        int summamax = 0;
        int min = Math.min(usernumber1,usernumber2);
        int max = Math.max(usernumber1,usernumber2);
        for (int i = 1; i < min; i++) {
            summamin = i + summamin;

            System.out.println(summamin);

        }
        for (int j = 1; j < max; j++) {
            summamax = j +summamax;

            System.out.println(summamax);
            summatotal=summamin+summamax;
        }
        do { System.out.println("For quit you most whrite _quit_");
            System.out.println(summatotal);
            user = scanner.nextLine();

        }while (!user.equalsIgnoreCase("quit"));


        }



    }


