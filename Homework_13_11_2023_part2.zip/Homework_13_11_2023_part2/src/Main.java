import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //№2
        //Напишите программу, которая принимает от пользователя его имя,
        // возраст (полных лет) и вес.
        // Когда все данные введены, программа должна выдать
        // сообщение: «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
        // В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.

        System.out.println("Input your Name :");
        Scanner scr2 = new Scanner(System.in);
        String name = scr2.next();
        System.out.println("Input your Age :");
        Scanner scr = new Scanner(System.in);
        int age = scr.nextInt();
        System.out.println("Input your Weight:");
        int weight =scr.nextInt();
        System.out.println("Уважаемый, "+name+"! В свои "+age+" лет Вы для нас дороги, как "+weight+" килограмм золота.");
    }
}