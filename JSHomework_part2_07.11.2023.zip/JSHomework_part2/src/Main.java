public class Main {
    public static void main(String[] args) {
// Дано трехзначное число. Вывести на экран все цифры этого числа
        System.out.println("Вывести на экран все цифры 345");
        int a = 345 / 100;
        int b = (345 / 10) % 10;
        byte c = 345 % 10;
        System.out.println("A=" + a);
        System.out.println("B=" + b);
        System.out.println("C=" + c);
        System.out.println("Вывести на экран все цифры 987");
        int d = 987 / 100;
        int f = (987 / 10) % 10;
        byte g = 987 % 10;
        System.out.println("Вывод в консоль:");
        System.out.println("D=" + d);
        System.out.println("F=" + f);
        System.out.println("G=" + g);
    }


}