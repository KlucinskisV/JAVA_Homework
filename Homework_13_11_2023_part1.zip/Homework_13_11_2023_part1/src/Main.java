import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //1 Напишите программу, в которой объявите переменные всех примитивных типов.
        // Значение для каждой переменной сгенерируйте с помощью класса Random.
        // При необходимости используйте приведение типов.
        // Полученные значения выведите в консоль.
        Random rnd = new Random();
        byte b = (byte) rnd.nextInt();
        int i = rnd.nextInt();
        boolean bool = rnd.nextBoolean();
        char c = (char) rnd.nextInt('A','Z'+1);
        long l = rnd.nextLong();
        float f = rnd.nextFloat();
        double d = rnd.nextDouble();
        System.out.println("Random Sample byte = "+b);
        System.out.println("Random Sample int = "+i);
        System.out.println("Random Sample boolean = "+bool);
        System.out.println("Random Sample char = "+c);
        System.out.println("Random Sample long = "+l);
        System.out.println("Random Sample float = "+f);
        System.out.println("Random Sample double = "+d);
        // 2 В этой же программе создайте переменную типа String.
        // Сгенерируйте значение для строки.
        // При необходимости используйте метод String.valueOf().
        // Ограничений на длину строки и содержимое нет.
        // Полученное значение выведите в консоль.
        Random rnd2 = new Random();
        String str1 = String.valueOf(rnd2.nextInt(-1000,1000));;
        System.out.println("String mod "+str1);
    }
}