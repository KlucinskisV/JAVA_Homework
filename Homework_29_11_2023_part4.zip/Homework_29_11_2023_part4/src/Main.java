import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //Создайте массив из 5 строк.
        // Используя метод length() строк,
        // найдите строку с наибольшей длиной и строк с наименьшей длиной.
        //Выведите массив и полученный строки в консоль.
        String [] string = {
                "Vladislav","Sergej","Tom","Aleksander","Dmitrij"
        };
        System.out.println(Arrays.toString(string));
        System.out.println("Hайдите строку с наибольшей длиной и строк с наименьшей длиной : ");
        for (String stringmax:string) {
            System.out.print(stringmax.length() + "  ");


        }
        int maxLengt = 0;
        int minLengt = string[0].length();
        String minword = "";
        String longword = "";
        for (int i = 0; i < string.length; i++) {
            if (string[i].length()> maxLengt){
                maxLengt = string[i].length();
                longword = string[i];
            }
            if (string[i].length()< minLengt){
                minLengt = string [i].length();
                minword = string[i];
            }


        }
        System.out.println("\n"+"Longes Word in Massiv : "+longword);
        System.out.println("\n"+"Smolest Word in Massiv : "+minword);


    }
}