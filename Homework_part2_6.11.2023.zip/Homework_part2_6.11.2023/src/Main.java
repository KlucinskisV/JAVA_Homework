public class Main {
    public static void main(String[] args) {
        System.out.printf("MY name %s , age %d ","Vladislav",35);
    }
}